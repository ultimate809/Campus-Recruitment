<!DOCTYPE html>
<html>
<style>
textarea {
 background: url(http://i.stack.imgur.com/ynxjD.png) repeat-y;
 width: 400px;
 height: 100px;
 font: normal 14px verdana;
 line-height: 25px;
 padding: 12px 20px;
 border: 1px solid #ccc;
 margin: 8px 0;
 border-radius: 4px;
 
}
input[type=text], select {
    width: 40%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 30%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    display: block;
    font-size: 15px; 
    font-weight: bold;
    
}



html
{
	height: 100%
}
body {
    border-radius: 5px;
    /*background-color: #f2f2f2;*/
    padding: 20px;
    background-image: url("com.jpeg");
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
</style>
<body >


<font size="10" color="brown"><b>Display Company Profile<br><br></b></font>
  <form method="POST">
    <label for="Company name"><font size="5" color="black"><b>Company Name&nbsp;</b></font></label>
    <input type="text" id="Company name" name="Company name" placeholder="Name">
	
    
  
    <input type="submit" value="Submit" method="POST" formaction="/answercom">
  </form>
  
</div>

</body>
</html>

