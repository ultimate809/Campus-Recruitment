<!DOCTYPE html>
<html>
<?php 
session_start();
?>
<style>
textarea {
 background: url(http://i.stack.imgur.com/ynxjD.png) repeat-y;
 width: 400px;
 height: 100px;
 font: normal 14px verdana;
 line-height: 25px;
 padding: 12px 20px;
 border: 1px solid #ccc;
 margin: 8px 0;
 border-radius: 4px;
 
}
input[type=text], select {
    width: 40%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 30%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    display: block;
    font-size: 15px; 
    font-weight: bold;
    
}



html
{
	height: 100%
}
body {
    border-radius: 5px;
    /*background-color: #f2f2f2;*/
    padding: 20px;
    background-image: url("com.jpeg");
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
</style>
<body >


<font size="10" color="red"><b>Company Profile<br><br></b></font>
  <form >
    <label for="Company name"><font size="5" color="orange"><b>Company Name&nbsp;</b></font></label>
    <font size="4" color="yellow"><b><?php 
		echo $_SESSION['compname']; 
	}
?></b></font>
	
    
  
   
  </form>

 <label for="Announcement"></br></br><font size="5" color="orange"><b>Company Data</b></font></br></label>
    <textarea  name="comment" form="usrform" placeholder="Type your Announcement...">{{data}}</textarea>

</div>

</body>
</html>

